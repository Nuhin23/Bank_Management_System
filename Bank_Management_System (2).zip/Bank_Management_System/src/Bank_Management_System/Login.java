 
package Bank_Management_System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
    // Declare components
    private JLabel welcomeLabel, cardLabel, pinLabel;
    private JTextField cardField;
    private JPasswordField pinField;
    private JButton signInButton, clearButton, signUpButton;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/bank_management_system";  // Replace with your database URL
    private static final String DB_USER = "root";  // Replace with your DB username
    private static final String DB_PASSWORD = "nuhin1129";  // Replace with your DB password

    // Constructor to set up the GUI
    public Login() {
        setTitle("AUTOMATED TELLER MACHINE");

        // ATM Logo
        ImageIcon logoIcon = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/logo.jpg"));
        Image scaledLogo = logoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogo));
        logoLabel.setBounds(70, 10, 100, 100);
        add(logoLabel);

        // Labels
        welcomeLabel = new JLabel("WELCOME TO ATM");
        welcomeLabel.setFont(new Font("Osward", Font.BOLD, 38));
        welcomeLabel.setBounds(200, 40, 450, 40);
        add(welcomeLabel);

        cardLabel = new JLabel("Card No:");
        cardLabel.setFont(new Font("Raleway", Font.BOLD, 28));
        cardLabel.setBounds(125, 150, 375, 30);
        add(cardLabel);

        pinLabel = new JLabel("PIN:");
        pinLabel.setFont(new Font("Raleway", Font.BOLD, 28));
        pinLabel.setBounds(125, 220, 375, 30);
        add(pinLabel);

        // Text fields for card number and PIN
        cardField = new JTextField(15);
        cardField.setBounds(300, 150, 230, 30);
        cardField.setFont(new Font("Arial", Font.BOLD, 14));
        add(cardField);

        pinField = new JPasswordField(15);
        pinField.setFont(new Font("Arial", Font.BOLD, 14));
        pinField.setBounds(300, 220, 230, 30);
        add(pinField);

        // Buttons
        signInButton = new JButton("SIGN IN");
        signInButton.setBackground(Color.BLACK);
        signInButton.setForeground(Color.WHITE);
        signInButton.setFont(new Font("Arial", Font.BOLD, 14));
        signInButton.setBounds(300, 300, 100, 30);
        add(signInButton);

        clearButton = new JButton("CLEAR");
        clearButton.setBackground(Color.BLACK);
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setBounds(430, 300, 100, 30);
        add(clearButton);

        signUpButton = new JButton("SIGN UP");
        signUpButton.setBackground(Color.BLACK);
        signUpButton.setForeground(Color.WHITE);
        signUpButton.setFont(new Font("Arial", Font.BOLD, 14));
        signUpButton.setBounds(300, 350, 230, 30);
        add(signUpButton);

        // Add action listeners
        signInButton.addActionListener(this);
        clearButton.addActionListener(this);
        signUpButton.addActionListener(this);

        // Set background color and layout
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Frame settings
        setSize(800, 480);
        setLocation(550, 200);
        setVisible(true);
    }

    // Action listener method for handling button clicks
    public void actionPerformed(ActionEvent ae) {
        try {
            // Sign In button clicked
            if (ae.getSource() == signInButton) {
                String cardNo = cardField.getText();
                String pin = new String(pinField.getPassword());

                // Validation for empty fields
                if (cardNo.isEmpty() || pin.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both card number and PIN.");
                    return;
                }

                // Establish database connection
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Query for checking login credentials
                    String query = "SELECT * FROM login WHERE cardno = ? AND pin = ?";
                    try (PreparedStatement pst = conn.prepareStatement(query)) {
                        pst.setString(1, cardNo);
                        pst.setString(2, pin);

                        ResultSet rs = pst.executeQuery();
                        // If user found, proceed to transactions window
                        if (rs.next()) {
                            setVisible(false);  // Hide login window
                            new Transactions(pin).setVisible(true);  // Open the Transactions window
                        } else {
                            JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database connection error.");
                }
            }

            // Clear button clicked
            else if (ae.getSource() == clearButton) {
                cardField.setText("");
                pinField.setText("");
            }

            // Sign Up button clicked
            else if (ae.getSource() == signUpButton) {
                setVisible(false);
                new Signup().setVisible(true);  // Open the Sign Up window
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}


