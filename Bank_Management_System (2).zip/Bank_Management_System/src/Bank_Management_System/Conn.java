 

package Bank_Management_System;

import java.sql.*;

public class Conn {
    Connection c;
    Statement s;

    public Conn() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database with the correct name
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_management_system", "root", "nuhin1129");

            // Create a statement
            s = c.createStatement();

            System.out.println("Connection established successfully!");
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
}
